#include<stdio.h>
extern int yyparse();
int main()
{
    yyparse();
}